/*
Dada una cadena, extraer la cuarta y quinta letra usando el método substring.
 */
package com.mycompany.practico2;

public class Practico2Ejercicio12 {
    public static void main(String[] args) {
       String cadena = "Xeneize";
       String extraido = cadena.substring(3,5);
        System.out.println("Las letras extraidas son: " + extraido);
    }
}
