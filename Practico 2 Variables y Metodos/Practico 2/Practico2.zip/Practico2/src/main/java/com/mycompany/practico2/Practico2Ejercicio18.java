/*
 En la clase FuncionesPrograma codifique una función estática que reciba como
parámetro 3 valores enteros, día, mes, anio y retorne la fecha de tipo Date
correspondiente.
public static Date getFechaDate(int día, int mes, int anio){
……….
}
En la clase Principal creada en el punto anterior haga uso de la función
getFechaDate.
 */
package com.mycompany.practico2;

//Realizado en Ejercicio 17 y Funciones programa.

public class Practico2Ejercicio18 {
    
    
}
